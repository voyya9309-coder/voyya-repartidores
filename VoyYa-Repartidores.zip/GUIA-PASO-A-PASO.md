# Guía paso a paso: crear la APK de ¡VoyYa! Repartidores con GitHub

Todo el proyecto ya está listo. Tú solo subes los archivos a GitHub y GitHub compila la APK por ti (gratis, sin instalar nada).

**Qué incluye la app**
- Tu `index.html` con la pantalla de inicio normal (carga con tu imagen, Inicio, avisos, enlaces, política).
- Menú solo con **Inicio** y **Repartidor** (sin Cliente, Negocio ni Administración).
- **Notificación de pedido nuevo en tiempo real aunque la app esté cerrada**, con tu audio `Repartidor.mp3` (suena también con la pantalla apagada).
- Se reactiva sola al encender el teléfono.
- Usa la misma base de datos Supabase que ya tienes: **no hay que ejecutar ningún SQL nuevo**.

---

## PARTE 1 · Crear la APK

### Paso 1 · Cuenta y repositorio
1. Entra en https://github.com y crea una cuenta gratis (o inicia sesión).
2. Arriba a la derecha pulsa **+ → New repository**.
3. Nombre: `voyya-repartidores`.
4. Marca **Private** (recomendado: el proyecto lleva tu clave de Supabase y la firma de la app).
5. Pulsa **Create repository**.

### Paso 2 · Subir los archivos (desde una computadora)
1. Extrae el ZIP `VoyYa-Repartidores.zip`.
2. En tu repositorio nuevo pulsa **uploading an existing file** (o **Add file → Upload files**).
3. Abre la carpeta extraída y arrastra **todo su contenido** (las carpetas `app` y `.github`, y los archivos `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `.gitignore`, `README.md`).
   - Si en Mac/Linux no ves `.github` porque está oculta: Mac → `Cmd + Shift + .`, Linux → `Ctrl + H`.
   - Si el navegador no sube la carpeta `.github`, usa el método con Git de abajo.
4. Abajo pulsa **Commit changes**.

**Método con Git (alternativa, más seguro):**
```bash
cd VoyYa-Repartidores
git init
git add -A
git commit -m "Primera versión"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/voyya-repartidores.git
git push -u origin main
```

### Paso 3 · Compilar
1. Ve a la pestaña **Actions** del repositorio.
2. Si te pide habilitar los workflows, pulsa **I understand my workflows, go ahead and enable them**.
3. Debería empezar sola ("Compilar APK Repartidores"). Si no: elige ese workflow a la izquierda → **Run workflow** → **Run workflow**.
4. Espera de 4 a 8 minutos hasta ver el check verde ✅.

### Paso 4 · Descargar la APK
- En la página principal del repositorio, columna derecha, pulsa **Releases** → **APK Repartidores #1** → descarga **VoyYa-Repartidores.apk**.
- También está en **Actions → (la ejecución) → Artifacts → VoyYa-Repartidores-APK** (viene dentro de un ZIP).

### Paso 5 · Repartirla a tus repartidores
Cualquiera de estas formas:
- Mándales el archivo `.apk` por WhatsApp o Telegram.
- Súbela desde tu panel de administrador (**Contenido → Subir aplicaciones (APK)**): les aparecerá en **Inicio → Descargar aplicaciones**.

---

## PARTE 2 · Instalar y dejarla lista en cada teléfono

1. Abre la APK. Si Android lo pide, activa **Instalar apps desconocidas** para esa aplicación (WhatsApp, Chrome, etc.).
2. Abre **¡VoyYa! Repartidores** y acepta los permisos:
   - **Notificaciones** → Permitir (imprescindible para el aviso con sonido).
   - **Ubicación** → Permitir (para el GPS de las entregas).
3. Inicia sesión o regístrate como repartidor.
4. Saldrá un aviso **"Para recibir pedidos con la app cerrada"** → pulsa **Permitir** (quita la restricción de batería).
5. Verás una notificación pequeña fija "Conectado: te avisaremos de los pedidos nuevos". Es normal y necesaria: es lo que mantiene la escucha activa con la app cerrada. No la quites.

### Ajustes extra según la marca del teléfono (muy importante)
Algunos fabricantes matan las apps en segundo plano. En esos teléfonos activa:
- **Xiaomi / Redmi / Poco:** Ajustes → Aplicaciones → Permisos → **Inicio automático** → activar para la app. Batería → Ahorro de batería de la app → **Sin restricciones**. En Recientes, mantén pulsada la app → candado 🔒.
- **Huawei / Honor:** Ajustes → Batería → Inicio de aplicaciones → la app → **Administrar manualmente** → activar las 3 opciones.
- **Samsung:** Ajustes → Aplicaciones → la app → Batería → **Sin restricciones**; y quítala de "Apps en suspensión".
- **Oppo / Realme / Vivo:** Permitir **Inicio automático** y **Actividad en segundo plano**; bloquear la app en Recientes.

### Probar que funciona
1. Entra como repartidor, comprueba que tienes **saldo suficiente** (la notificación solo llega si tu saldo cubre la comisión por entrega).
2. **Cierra la app** (sácala de Recientes) y apaga la pantalla.
3. Desde otro teléfono haz un pedido y, en el negocio, ponlo en **Listo**.
4. Debe sonar tu audio y aparecer **"🛵 ¡Nuevo pedido disponible!"**. Al tocarla se abre directamente la pestaña **Repartidor**.

---

## PARTE 3 · Actualizar la app más adelante
1. En GitHub abre `app/src/main/assets/index.html` → icono del lápiz ✏️ → cambia lo que necesites → **Commit changes** (o sube el archivo nuevo con la misma ruta).
2. GitHub compila otra APK solo (Actions → Releases).
3. Instálala **encima** de la anterior: no hace falta desinstalar ni volver a iniciar sesión (la firma es siempre la misma y el número de versión sube solo).

Nota: los cambios de **diseño y textos que haces desde tu panel** (colores, banner, avisos, enlaces, política, ajustes) se ven **al instante sin actualizar la APK**, porque vienen de Supabase.

---

## Cómo funciona la notificación con la app cerrada (por si te preguntan)
- La app incluye un **servicio en primer plano** que mantiene una conexión en tiempo real directa con tu Supabase (tabla `pedidos`).
- Cuando un pedido pasa a **Listo** y nadie lo ha tomado, lanza una notificación con tu audio.
- Si otro repartidor lo toma, la notificación desaparece sola.
- Cada 30 segundos revisa por si se perdió algún aviso (cortes de internet) y se reconecta sola.
- **No usa Firebase/Google**, así que no necesitas crear ninguna cuenta ni claves extra.
- Si la cuenta se banea o elimina, el servicio se apaga solo.
- Con la app **abierta** suena el mismo audio desde la propia pantalla (no se duplica).

## Cosas que debes saber
- **Primera compilación:** este proyecto lo preparé sin poder ejecutar Android Studio, así que si GitHub Actions muestra un error ❌, abre la ejecución, copia las últimas líneas rojas del log y envíamelas: lo corrijo enseguida.
- **Internet:** la app carga Tailwind, Supabase, Leaflet y Lucide desde internet (igual que tu página actual), por lo que necesita datos o WiFi.
- **GPS en segundo plano:** el GPS de la entrega en curso lo comparte la pantalla de la app; si el repartidor deja la app en segundo plano mucho rato, Android puede pausar ese envío. Las notificaciones de pedidos nuevos sí funcionan siempre. Si quieres, el siguiente paso es llevar también el GPS a un servicio nativo.
- **Cambiar el audio:** reemplaza `app/src/main/res/raw/repartidor.mp3` y `app/src/main/assets/Repartidor.mp3` (mismo nombre, en minúsculas el de `res/raw`). Android guarda el sonido del canal la primera vez, así que además cambia `CH_ORDERS = "pedidos_v1"` por `"pedidos_v2"` en `OrderService.kt`.
- **Seguridad:** la firma de la app (`app/voyya.keystore`) está en el repositorio para que las actualizaciones se instalen encima. Mantén el repositorio **privado**. Además, tus políticas de Supabase son abiertas (como avisa tu propio SQL): cuando tengas muchos usuarios reales conviene endurecerlas.

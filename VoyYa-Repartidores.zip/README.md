# ¡VoyYa! Repartidores (APK)

App Android de repartidores: tu misma página `index.html` (pantalla de inicio normal) dentro de una app nativa que:

- Muestra solo **Inicio** y **Repartidor** (sin Cliente, Negocio ni Administración).
- Recibe **notificaciones de pedidos nuevos en tiempo real aunque la app esté cerrada**, con tu audio `Repartidor.mp3`.
- Arranca sola al encender el teléfono.

Guía completa paso a paso: ver `GUIA-PASO-A-PASO.md`.
